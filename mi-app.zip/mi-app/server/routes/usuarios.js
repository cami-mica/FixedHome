const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/', async (req, res) => {
  const { nombre, apellido, direccion, ocupacion, tipo_vivienda } = req.body;
  try {
    const conn = await db.getConnection();
    await conn.query(
      'INSERT INTO usuarios (nombre, apellido, direccion, ocupacion, tipo_vivienda) VALUES (?, ?, ?, ?, ?)',
      [nombre, apellido, direccion, ocupacion, tipo_vivienda]
    );
    conn.release();
    res.sendStatus(201);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error en el registro de usuario' });
  }
});

module.exports = router;