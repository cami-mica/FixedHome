const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/registrar', async (req, res) => {
  const { nombre, apellido, direccion, ocupacion, oficios } = req.body;
  try {
    const conn = await db.getConnection();
    await conn.query(
      'INSERT INTO profesionales (nombre, apellido, direccion, ocupacion, oficios) VALUES (?, ?, ?, ?, ?)',
      [nombre, apellido, direccion, ocupacion, oficios]
    );
    conn.release();
    res.send('Profesional registrado correctamente');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error al registrar profesional');
  }
});

module.exports = router;
