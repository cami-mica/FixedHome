const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const usuariosRoutes = require('./routes/usuarios');
const profesionalesRoutes = require('./routes/profesionales');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Servir archivos estáticos desde carpeta 'public'
app.use(express.static(path.join(__dirname, '../public')));

// Ruta para servir el archivo index.html al acceder a la raíz
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Rutas API
app.use('/api/usuarios', usuariosRoutes);
app.use('/api/profesionales', profesionalesRoutes);

// Puerto de escucha
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en puerto ${PORT}`);
});