// Mostrar/ocultar opciones de registro
const btnRegistrarse = document.getElementById('btn-registrarse');
const opcionesRegistro = document.getElementById('opciones-registro');

const formularioUsuario = document.getElementById('formulario-usuario');
const formularioProfesional = document.getElementById('formulario-profesional');

btnRegistrarse.addEventListener('click', () => {
  opcionesRegistro.classList.toggle('oculto');
  formularioUsuario.classList.add('oculto');
  formularioProfesional.classList.add('oculto');
});

// Mostrar formularios según selección
document.getElementById('registro-usuario').addEventListener('click', () => {
  formularioUsuario.classList.remove('oculto');
  formularioProfesional.classList.add('oculto');
  opcionesRegistro.classList.add('oculto');
});

document.getElementById('registro-profesional').addEventListener('click', () => {
  formularioProfesional.classList.remove('oculto');
  formularioUsuario.classList.add('oculto');
  opcionesRegistro.classList.add('oculto');
});

// Manejar envío formulario usuario
document.getElementById('form-usuario').addEventListener('submit', async (e) => {
  e.preventDefault();

  const form = e.target;
  const data = {
    nombre: form.nombre.value.trim(),
    apellido: form.apellido.value.trim(),
    direccion: form.direccion.value.trim(),
    ocupacion: form.ocupacion.value.trim(),
    tipo_vivienda: form.tipo_vivienda.value
  };

  try {
    const res = await fetch('http://localhost:3000/api/usuarios/registrar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const text = await res.text();
    document.getElementById('mensaje-usuario').textContent = text;
    if (res.ok) form.reset();
  } catch (error) {
    document.getElementById('mensaje-usuario').textContent = 'Error al registrar usuario.';
  }
});

// Manejar envío formulario profesional
document.getElementById('form-profesional').addEventListener('submit', async (e) => {
  e.preventDefault();

  const form = e.target;
  const data = {
    nombre: form.nombre.value.trim(),
    apellido: form.apellido.value.trim(),
    direccion: form.direccion.value.trim(),
    ocupacion: form.ocupacion.value.trim(),
    oficios: form.oficios.value.trim()
  };

  try {
    const res = await fetch('http://localhost:3000/api/profesionales/registrar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const text = await res.text();
    document.getElementById('mensaje-profesional').textContent = text;
    if (res.ok) form.reset();
  } catch (error) {
    document.getElementById('mensaje-profesional').textContent = 'Error al registrar profesional.';
  }
});

// Ejemplo para cargar perfiles profesionales (hardcodeados)
const perfiles = [
  {
    nombre: "Lucas",
    apellido: "Martínez",
    ocupacion: "Electricista",
    oficios: "electricidad, cableado"
  },
  {
    nombre: "Sofía",
    apellido: "García",
    ocupacion: "Plomera",
    oficios: "plomería, reparación"
  }
];

const listaProfesionales = document.getElementById('lista-profesionales');

function mostrarPerfiles() {
  listaProfesionales.innerHTML = '';
  perfiles.forEach(p => {
    const div = document.createElement('div');
    div.classList.add('perfil');
    div.innerHTML = `
      <h3>${p.nombre} ${p.apellido}</h3>
      <p><strong>Ocupación:</strong> ${p.ocupacion}</p>
      <p><strong>Oficios:</strong> ${p.oficios}</p>
    `;
    listaProfesionales.appendChild(div);
  });
}

mostrarPerfiles();
